import { Component } from '@angular/core';

@Component({
  selector: 'app-depositb',
  templateUrl: './depositb.component.html',
  styleUrls: ['./depositb.component.css']
})
export class DepositbComponent {

}
