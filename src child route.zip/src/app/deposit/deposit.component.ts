import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent {
constructor(private route:ActivatedRoute, private router:Router){

}
coins()
{
  this.router.navigate(['coins'],{relativeTo:this.route})
}
notes()
{
  this.router.navigate(['notes'],{relativeTo:this.route})
}
}
