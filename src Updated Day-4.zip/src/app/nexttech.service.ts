import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NexttechService { //ng g s productsservice

  constructor() { 
    console.log("service instantiated")
  }

  public getProducts() {
    let products: Product[];
        products=[
          new Product(1,'mobile',9000,'electronics'),
          new Product(2,'pendrive',2000,'electronics'),
          new Product(3,'teddy',5000,'toys'),
          new Product(4,'dal',9000,'groceries')
        ]
        return products;
  }







}
export class Product {
  productId: number;
  productName: string;
  productPrice: number;
  productCategory: string
  constructor(productId: number, productName: string, productPrice: number, productCategory: string) {
    this.productId = productId;
    this.productName = productName
    this.productPrice = productPrice
    this.productCategory = productCategory
  }
}
