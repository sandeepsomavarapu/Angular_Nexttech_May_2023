import { Component } from '@angular/core';
import { NexttechService } from '../nexttech.service';

@Component({
  selector: 'emps',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent {


  emps:any[];
  constructor() {
   
    this.emps=[
      {empcode:'emp101',name:"AKASH",dateOfBirth:'NOV/10/1993',gender:"male",sal:12000.123},
     {empcode:'emp102',name:"pranay kumar" ,dateOfBirth:'08/23/1990',gender:"male",sal:22000.123},
    {empcode:'emp103',name:"srikanth", dateOfBirth:'06/11/1991',gender:"male", sal:32000.121},
    {empcode:'emp104',name:"deepa sri" ,dateOfBirth:'07/15/1988',gender:"female",sal:42000.900},
    {empcode:'emp105',name:"ramya" ,dateOfBirth:'06/19/1993',gender:"female",sal:20000.631}
      ];
   }


}
