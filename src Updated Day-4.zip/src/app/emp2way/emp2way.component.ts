import { Component } from '@angular/core';

@Component({
  selector: 'emp2way',
  templateUrl: './emp2way.component.html',
  styleUrls: ['./emp2way.component.css']
})
export class Emp2wayComponent {

  employee:any;
  constructor() {
    this.employee = {
      FirstName : "sandeep",
      LastName : "Kumar",
      Gender : "Male"
  };
 }

}
