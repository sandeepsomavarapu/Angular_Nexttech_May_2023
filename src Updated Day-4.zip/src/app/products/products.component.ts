import { Component } from '@angular/core';
import { NexttechService, Product } from '../nexttech.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent {
  products:Product[];
  nextTechservice:NexttechService;
  constructor(service:NexttechService) {
    this.nextTechservice=service;
    this.getProducts();
  }
  getProducts()
  {
    this.products=this.nextTechservice.getProducts()
  }
}
