import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { EmployeesComponent } from './employees/employees.component';
import { AuthGuard } from './auth.guard';
import { ProductsComponent } from './products/products.component';
import { UsersComponent } from './users/users.component';
import { AdduserComponent } from './adduser/adduser.component';
import { UpdateuserComponent } from './updateuser/updateuser.component';

const routes: Routes = [
  { path: "login", component: LoginComponent },
  { path: "register", component: RegisterComponent },
  { path: "products", component: ProductsComponent,canActivate:[AuthGuard] },
  { path: "emps", component: EmployeesComponent,canActivate:[AuthGuard]},
  {path:"users",component:UsersComponent,canActivate:[AuthGuard]},
  { path:"adduser", component: AdduserComponent },
  { path:"updateuser", component: UpdateuserComponent },
  { path: "", component: RegisterComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
