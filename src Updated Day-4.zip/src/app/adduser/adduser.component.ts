import { Component } from '@angular/core';
import { UsersService,User } from '../users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent {

  constructor(private userService:UsersService,private router:Router)
  {

  }

  onSubmit(user:User)
  {
    this.userService.addUser(user).subscribe(data => {
      alert("User Added successfully");
      this.router.navigate(['/users']);
    });}
}
