import { Component } from '@angular/core';
import { UsersService } from '../users.service';
import { User } from '../users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent {
  users:User[];
  error=null;
constructor(private userService:UsersService,private router:Router)
{
  this.userService.getUsers().subscribe(
    response => this.handleSuccessfulResponse(response)
    ,
    error=>{this.error=error.message}
  );
}
handleSuccessfulResponse(response) {
  console.log(response)
  this.users = response;
//  this.filteredEmployees=this.employees;
}
update(updateuser: User) {
  this.userService.update(updateuser);
   this.router.navigate(['/updateuser']); //updating the employee
 }
 delete(deleteuser: User): any {
   var selction= confirm("Are you sure !!")
    if(selction==true){
       this.users.splice(this.users.indexOf(deleteuser),1);
     this.userService.delete(deleteuser.id).subscribe(data => {
       alert(data);
     });}
}


}