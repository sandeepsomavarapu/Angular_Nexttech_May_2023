import { Component } from '@angular/core';
import { User, UsersService } from '../users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-updateuser',
  templateUrl: './updateuser.component.html',
  styleUrls: ['./updateuser.component.css']
})
export class UpdateuserComponent {
  obj1: any;
  employees: User[];
  message: string;
  constructor(private myservice: UsersService, private router: Router) {
    this.obj1 = this.myservice.updateMethod();
  }
  onUpdate(updateUser: User): any {
    return this.myservice.onUpdate(updateUser).subscribe(data => {
      alert("Updated Successfully")
      this.router.navigate(['/users'])
    });
  }
}
