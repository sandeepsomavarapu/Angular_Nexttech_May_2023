import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  user:User;

  constructor(private httpClient:HttpClient) { }

  public getUsers() {
    console.log("ins service get employees");//headers
      return this.httpClient.get<User>("http://localhost:3000/users");
    }

    public addUser(user: User) {
      console.log("ins service add");
      console.log(user);
      return this.httpClient.post("http://localhost:3000/users", user);
    }
    public update(updateuser: User) {
      this.user = updateuser;
    }
    public updateMethod() {
      return this.user;
    }
    public onUpdate(updatemp: User) {
      console.log("ins service update");
  
      return this.httpClient.put("http://localhost:3000/users/"+updatemp.id,updatemp);
    }
    delete(id: number) {
      console.log("ins service delete");
      return this.httpClient.delete("http://localhost:3000/users/" + id);
    }
  
}
export class User {
  id: number;
  name: string;
  email: string;
}