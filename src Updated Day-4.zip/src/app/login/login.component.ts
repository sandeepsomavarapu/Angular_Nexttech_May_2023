import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
username:string;
password:string;
name='India'
constructor(private router:Router)
{

}
validate(data)
{
 this.username=data.uname
  this.password=data.pswd
  console.log(this.username+" "+this.password)
  if(this.username==="nexttech" && this.password==="nexttech123")
  {
    localStorage.setItem("uname",this.username);
    alert("Login Success")
    this.router.navigate(['emps'])
  }
  else{
    alert("Enter valid Credentials")
  }
}
}
