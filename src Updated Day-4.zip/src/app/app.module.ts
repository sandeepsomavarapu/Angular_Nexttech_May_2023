import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { EmployeesComponent } from './employees/employees.component';
import { GenderPipe } from './gender.pipe';
import { ChildComponent } from './child/child.component';
import { Emp2wayComponent } from './emp2way/emp2way.component';
import { FormsModule } from '@angular/forms';
import { ProductsComponent } from './products/products.component';
import { NexttechService } from './nexttech.service';
import { UsersComponent } from './users/users.component';
import { HttpClientModule } from '@angular/common/http';
import { AdduserComponent } from './adduser/adduser.component';
import { UpdateuserComponent } from './updateuser/updateuser.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    EmployeesComponent,
    GenderPipe,
    ChildComponent,
    Emp2wayComponent,
    ProductsComponent,
    UsersComponent,
    AdduserComponent,
    UpdateuserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [NexttechService],
  bootstrap: [AppComponent]
})
export class AppModule { }
