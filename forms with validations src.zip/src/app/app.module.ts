import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TemplatedrivenComponent } from './templatedriven/templatedriven.component';
import { ModelDrivenComponent } from './model-driven/model-driven.component';
import { TemplateValidComponent } from './template-valid/template-valid.component';

@NgModule({
  declarations: [
    AppComponent,
    TemplatedrivenComponent,
    ModelDrivenComponent,
    TemplateValidComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
