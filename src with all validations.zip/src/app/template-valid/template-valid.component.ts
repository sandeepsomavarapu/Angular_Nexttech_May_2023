import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'validations',
  templateUrl: './template-valid.component.html',
  styleUrls: ['./template-valid.component.css']
})
export class TemplateValidComponent implements OnInit {

  constructor() { }
  onSubmit(data:NgForm)
  {
    console.log(data)
    console.log(data.value)
    alert(data.value.id)
    alert(data.value.name)
    alert(data.value.salary)
    alert(data.value.phonenumber)
    alert(data.value.company)

  }
  ngOnInit() {
  }

}
