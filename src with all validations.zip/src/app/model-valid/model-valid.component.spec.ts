import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelValidComponent } from './model-valid.component';

describe('ModelValidComponent', () => {
  let component: ModelValidComponent;
  let fixture: ComponentFixture<ModelValidComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModelValidComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelValidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
