import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'template-driven',
  templateUrl: './templatedriven.component.html',
  styleUrls: ['./templatedriven.component.css']
})
export class TemplatedrivenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  onSubmit(contactForm1) {
    alert(contactForm1.value.email);
    alert(contactForm1.value.lastname);
    alert(contactForm1.value.firstname);
  }
  countryList:country[] = [
    new country("1", "India"),
    new country('2', 'USA'),
    new country('3', 'England')
  ];
}
export class country {
  id:string;
  name:string;
  constructor(id:string, name:string) {
    this.id=id;
    this.name=name;
  }}