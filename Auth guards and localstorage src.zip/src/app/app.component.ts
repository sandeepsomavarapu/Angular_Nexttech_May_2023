import { Component } from '@angular/core';

@Component({
  selector: 'app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'NextTech';
  username: string = "NextTech@123"

  childData: string;
  parentMethod(data: string) {
    this.childData = data
  }
  isLoggedIn() {
    if(localStorage.getItem("uname")!=null)
    return true;
    else{
    return false 
    }
  }
  logout() {
    // localStorage.getItem("uname");
    localStorage.removeItem("uname")
    alert("logged out successfully")
  }
}
